<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="Shortcut Icon" type="image/x-icon" href="img/logoicono.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ACCESO</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css"
        rel="stylesheet"
        integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx"
        crossorigin="anonymous"/>
</head>
<body>

    <style>
        body{
            background-image: url('https://www.solofondos.com/wp-content/uploads/2016/10/fondo-rojo-degradado.jpg');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100% 100%;
        }
    </style>
    
<?php
    $usuario=$_POST["tus"];
	$clave=$_POST["tcla"];

    require("conexion.php");
	$con=conectar();
	$sql="select * from usuarios where usuario='$usuario'";
	$rs=mysqli_query($con, $sql);
	$num=mysqli_num_rows($rs);
	$row=mysqli_fetch_array($rs);
	if($num>0)
	{	
		
		$clavex=$row["clave"];	
		   
		if (crypt($clave, $clavex) == $clavex) 
		{
			session_start();
			$_SESSION["usuario"]=$us;
			$_SESSION["clave"]=$cla;
            $_SESSION["nombre"]=$row["nombre"];
			$_SESSION["nivel"]=$row["nivel"]; 
			header("location:home.php"); 
		}		
		else
		{	
		?>
        <br><br><br><br><br><br><br><br><br>
        <div class="card text-center container-fluid" style="width: 20rem;">
        <br>
            <img src="img/logoicono.ico" style="width: 10rem; height: 9rem;" class="container-fluid">
            <div class="card-body">
                <h5 class="card-title">ADVERTENCIA!!!!</h5>
                <p class="card-text">USUARIO O CLAVE INCORRECTOS!!!</p>
                <a href="index.html" class="btn btn-dark">REGRESAR</a>
            </div>
        </div>
        <?php			 		
		}
	}	
	else
	{ 
		 ?>
         <br><br><br><br><br><br><br><br><br>
         <div class="card text-center container-fluid" style="width: 20rem;">
         <br>
            <img src="img/logoicono.ico" style="width: 10rem; height: 9rem;" class="container-fluid">
            <div class="card-body">
                <h5 class="card-title">ADVERTENCIA!!!!</h5>
                <p class="card-text">USUARIO O CLAVE INCORRECTOS!!!</p>
                <a href="index.html" class="btn btn-dark">REGRESAR</a>
            </div>
        </div>
        <?php	
	}

?>

</body>
</html>