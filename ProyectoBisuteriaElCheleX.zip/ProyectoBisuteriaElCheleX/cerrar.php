<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="Shortcut Icon" type="image/x-icon" href="img/logoicono.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bisuteria El Chele'X - Cierre de Sesión</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css"
        rel="stylesheet"
        integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx"
        crossorigin="anonymous"/>
</head>
<body>

    <style>
        body{
            background-image: url('https://www.solofondos.com/wp-content/uploads/2016/10/fondo-rojo-degradado.jpg');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100% 100%;
        }
    </style>

    <?php
        session_start();
        // Eliminar todas las sesiones:
        session_unset();
        // Terminar la sesión:
        session_destroy();
    ?>
    <br><br><br><br><br><br><br><br><br>
    <div class="card text-center container-fluid" style="width: 20rem;">
    <br>
        <img src="img/logoicono.ico" style="width: 10rem; height: 9rem;" class="container-fluid">
        <div class="card-body">
            <h5 class="card-title">Cierre de sesión</h5>
            <p class="card-text">SESIÓN CERRADA!!!</p>
            <a href="index.html" class="btn btn-dark">CERRAR</a>
        </div>
    </div>
</body>
</html>

