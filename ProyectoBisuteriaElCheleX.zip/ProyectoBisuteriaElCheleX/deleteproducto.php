<?php
include("conexion.php");
$con=conectar();

$codigo=$_GET['id'];

$sql="delete from productos where codproducto = '$codigo'";
$query=mysqli_query($con,$sql);

    if($query){
        Header("Location: productos.php");
    }
?>
