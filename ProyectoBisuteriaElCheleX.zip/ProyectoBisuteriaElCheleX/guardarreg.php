<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="Shortcut Icon" type="image/x-icon" href="img/logoicono.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de usuarios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css"
        rel="stylesheet"
        integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx"
        crossorigin="anonymous"/>
</head>
<body>

<?php
    require("conexion.php");
    $con=conectar();

    $nombre=$_POST['tnombre'];
    $user=$_POST['tus'];
    $clave=$_POST['tclave'];
    $claveR=$_POST['tclaveR'];

    if(!(isset($_POST["admin"]))){ 
        $nivel = 0; //Usuario estándar
	}

    if(!(isset($_POST["userex"]))){ 
        $nivel = 1; //Administrador
	}

    $sql="SELECT usuario FROM usuarios where usuario = '$user'";
    $query=mysqli_query($con,$sql);
    $row = mysqli_num_rows($query);

    if($row>0){
        ?>
        <h3>ESTE USUARIO YA EXISTE</h3>

        <?php
    }
    else{
        if($clave==$claveR){
            $clave=crypt($clave,$clave); //encriptar la clave
    
            $sql ="INSERT INTO usuarios(usuario, clave, nivel, nombre) VALUES('$user','$clave','$nivel','$nombre')";
            $query = mysqli_query($con,$sql);
    
            if($query){
                Header("Location: index.html");       
            }
            else{
            }
        }
        else{?>
    
            <h3>LAS CLAVES NO CONCUERDAN!!!!</h3>

            <script>
                function r(){
                    location.href="registrar.php";
                }
                setTimeout((r) => {
                    
                }, 3000);
            </script>
            
        <?php
        }
    }
?>    
</body>
</html>