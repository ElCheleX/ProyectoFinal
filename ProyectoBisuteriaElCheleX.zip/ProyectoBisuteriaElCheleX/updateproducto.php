<?php
include("conexion.php");
$con=conectar();

$codigo=$_POST['codigo'];
$nombre=$_POST['nombre'];
$exis=$_POST['existencia'];
$codprovee=$_POST['codprovee'];
$coddepto=$_POST['coddepto'];

$sql="update productos set nombre='$nombre', existencia='$exis', codproveedor='$codprovee', coddepto='$coddepto' where codproducto='$codigo'";
$query=mysqli_query($con,$sql);

    if($query){
        Header("Location: productos.php");
    }
?>