<?php
include("conexion.php");
$con=conectar();

$codigo=$_POST['codigo'];
$nombre=$_POST['nombre'];
$exis=$_POST['existencia'];
$codprovee=$_POST['codprovee'];
$coddep=$_POST['coddepto'];


$sql ="insert into productos(codproducto, nombre, existencia, codproveedor, coddepto) values('$codigo','$nombre','$exis','$codprovee','$coddep')";
$query = mysqli_query($con,$sql);

if($query){
    Header("Location: productos.php");    
}else {
}
?>