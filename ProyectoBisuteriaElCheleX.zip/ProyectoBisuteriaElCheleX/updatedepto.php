<?php
include("conexion.php");
$con=conectar();

$codigo=$_POST['codigo'];
$nombre=$_POST['nombre'];

$sql="update departamentos set nombre='$nombre' where coddepto='$codigo'";
$query=mysqli_query($con,$sql);

    if($query){
        Header("Location: deptos.php");
    }
?>