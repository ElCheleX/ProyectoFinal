<?php
include("conexion.php");
$con=conectar();

$codigo=$_POST['codigo'];
$nombre=$_POST['nombre'];

$sql ="insert into departamentos(coddepto, nombre) values('$codigo','$nombre')";
$query = mysqli_query($con,$sql);

if($query){
    Header("Location: deptos.php");    
}else {
}
?>