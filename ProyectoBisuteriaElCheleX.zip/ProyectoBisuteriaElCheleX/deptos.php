<?php session_start();
	$nombre = $_SESSION["nombre"];
    $derechos = $_SESSION["nivel"];

    require("conexion.php");
    $con=conectar();

    $sql="select * from departamentos";
    $query=mysqli_query($con,$sql);
    $row = mysqli_num_rows($query);
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <link rel="Shortcut Icon" type="image/x-icon" href="img/logoicono.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="css/styles.css"/>
    <title>Bisuteria El Chele'X - Departamentos</title>
</head>

<body>
    <div class="d-flex" id="wrapper">
        <div class="bg-white" id="sidebar-wrapper">
            <div class="sidebar-heading text-center py-4 primary-text fs-4 fw-bold text-uppercase border-bottom">
                <a href="home.php"><img src="img/logoicono.ico" style="height: 10rem"/></a></div>
            <div class="list-group list-group-flush my-3">
                <a href="productos.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-tachometer-alt me-2"></i>Productos</a>
                <a href="deptos.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-project-diagram me-2"></i>Departamentos</a>
                <a href="provee.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-chart-line me-2"></i>Proveedores</a>
                <a href="movim.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-paperclip me-2"></i>Movimientos</a>
                <a href="ventas.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-shopping-cart me-2"></i>Ventas</a>
                <a href="cerrar.php" class="list-group-item list-group-item-action bg-transparent text-danger fw-bold"><i
                        class="fas fa-power-off me-2"></i>Cerrar Sesión</a>
            </div>
        </div>
        <div id="page-content-wrapper">
            <nav class="navbar navbar-expand-lg navbar-light bg-transparent py-4 px-4">
                <div class="d-flex align-items-center">
                    <i class="fas fa-align-left primary-text fs-4 me-3" id="menu-toggle"></i>
                    <h2 class="fs-2 m-0">Panel del Menú Principal</h2>
                </div>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link second-text fw-bold">
                                <i class="fas fa-user me-2"></i><?php echo $nombre; ?>
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <?php

            if($derechos == 1){
            ?>
                <div class="col-md-4 container-fluid text-center">
                    <h1>Añadir un nuevo departamento</h1>
                        <form action="insertdepto.php" method="POST">
                            <input type="text" class="form-control mb-4" name="codigo" placeholder="Código del Departamento">
                            <input type="text" class="form-control mb-4" name="nombre" placeholder="Nombre del Departamento">                          
                            <button type="summit" class="btn btn-info text-black w-100 fw-bold shadow-sm">Insertar Departamento</button>
                        </form>
                </div>
            <?php
            }
            else{
            }

            ?>

            <div class="container-fluid px-4 text-center">
                <div class="row my-5">
                    <div class="col">
                        <table class="table bg-white rounded shadow-sm  table-hover">
                            <thead>
                                <tr>
                                    <th scope="col" width="50">Código</th>
                                    <th scope="col">Nombre</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php
                                    while($row=mysqli_fetch_array($query)){
                                ?>

                                <tr>
                                    <th scope="row"><?php echo $row['coddepto']?></th>
                                    <td><?php echo $row['nombre']?></td>
                                    <?php
                                    if($derechos == 1){
                                        ?>
                                        <td><a href="actudepto.php?id=<?php echo $row['coddepto'] ?>" class="btn btn-info">Modificar</a></td>
                                        <td><a href="deletedepto.php?id=<?php echo $row['coddepto'] ?>" class="btn btn-danger">Eliminar</a></td>
                                        <?php
                                    }
                                    else{
                                    }
                                    ?>                                   
                                </tr>
                                <?php
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        var el = document.getElementById("wrapper");
        var toggleButton = document.getElementById("menu-toggle");

        toggleButton.onclick = function () {
            el.classList.toggle("toggled");
        };
    </script>
</body>

</html>