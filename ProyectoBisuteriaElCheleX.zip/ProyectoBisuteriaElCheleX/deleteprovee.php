<?php
include("conexion.php");
$con=conectar();

$codigo=$_GET['id'];

$sql="delete from proveedores where codproveedor = '$codigo'";
$query=mysqli_query($con,$sql);

    if($query){
        Header("Location: provee.php");
    }
?>
