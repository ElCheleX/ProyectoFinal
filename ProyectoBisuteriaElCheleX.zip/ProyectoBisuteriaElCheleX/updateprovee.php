<?php
include("conexion.php");
$con=conectar();

$codigo=$_POST['codigo'];
$nombre=$_POST['nombre'];
$dire=$_POST['dire'];
$tel=$_POST['tel'];
$cel=$_POST['cel'];

$sql="update proveedores set nombre='$nombre', direccion='$dire', telefono='$tel', celular='$cel' where codproveedor='$codigo'";
$query=mysqli_query($con,$sql);

    if($query){
        Header("Location: provee.php");
    }
?>